# Air Defense 101 — Digital-7 intro

Extract the ZIP, then open index.html in a browser and press PLAY INTRO.
Keep all files together. No installation or internet connection is needed.

Included: Digital-7 font, black background, green text, letter-by-letter typing,
Skip Intro, pause/resume, a readable transcript, and your selected soundtrack.
Music starts after the player clicks Play. Music and typing pause when the page
is hidden. The demo shows RADAR ONLINE after finishing or skipping.

## Edit the intro

- intro.js: story text, typing delays, scene holds, and music volume.
- intro.css: font size, layout, and green color (#58ff7e).
- assets/intro-music.mp3: your soundtrack, repeated with a crossfade for this intro.
- game-integration.js: connect completion to your actual Mission 1 code.

The expanded story runs for approximately 76 seconds. The original 20–30-second
limit requires shortening the story. The displayed runtime is calculated from
the text and delays, so it updates when you edit them.

## Connect to the game

Replace the example listener body in game-integration.js with your game's radar
and mission-start functions. The `introcomplete` event supplies
`event.detail.mission` (1) and `event.detail.skipped` (true or false).
Both Skip Intro and normal completion emit this event once per playthrough.
Combat timers should begin only after this event.

When embedding in an existing HTML game, include intro.css and intro.js, then
copy the #air-defense-intro element from index.html into your page. Start from
your menu with `window.airDefenseIntro.start()`. This is HTML/CSS/JavaScript
source; it has not been integrated into or tested inside your Android APK.

## Font credit

Digital-7 by Sizenko Alexander / Style-7.
Original font license is included in assets/FONT-LICENSE.txt. It specifies
home/freeware usage terms and separate commercial licensing terms.
