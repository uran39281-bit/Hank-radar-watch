(() => {
  const root = document.getElementById('air-defense-intro');
  const find = name => root.querySelector('.dw-' + name);
  const landing = find('landing'), stage = find('stage'), ending = find('ending');
  const transcript = find('transcript'), story = find('story'), typed = find('typed');
  const accessible = find('accessible'), pause = find('pause'), skip = find('skip');
  const play = find('play'), replay = find('replay'), read = find('read'), close = find('close');
  const music = find('music'), sound = find('sound');
  // Set to 0 for a silent intro; the MUSIC button also toggles sound.
  music.volume = 0.65;
  let audioBlocked = false;
  function updateSound() {
    sound.textContent = audioBlocked ? 'PLAY MUSIC' : music.muted ? 'MUSIC OFF' : 'MUSIC ON';
    sound.setAttribute('aria-pressed', String(!music.muted && !audioBlocked));
  }
  function playMusic() {
    if (!playing || paused || suspended) return;
    const request = music.play();
    if (request && request.catch) request.catch(() => {
      if (playing && !paused && !suspended) { audioBlocked = true;updateSound(); }
    });
  }
  // Edit the story here. \n creates a line break.
  const scenes = [
    '6 OCTOBER 1973\n0445 HOURS',
    'The first explosion throws the sleeping city into darkness.\nFor a moment, no one understands what has happened.',
    'Then the sirens begin.\nParents carry children into stairwells. Some never reach the shelters.',
    'An apartment block collapses.\nSurvivors call into the rubble. Some hear answers. Others hear nothing.',
    'At the airfield, hangars burn with crews still inside.\nRescuers reach one doorway just as the roof gives way.',
    'Runways are torn apart. Fighters burn on the ground.\nAn ambulance crew lifts a wounded pilot onto its last stretcher.',
    'Across the defense network, voices plead for help.\nOne transmission ends in a scream. The next is swallowed by static.',
    'Several batteries have fallen silent.\nNo one knows how many crews are still alive.',
    'Your cabin shudders. Dust falls onto the radar screen.\nA young operator wipes it away with a shaking hand.',
    '"All remaining batteries... fighter support is unavailable.\nHold until reinforcements arrive."',
    'Beyond the wire, the city is burning.\nYour crew looks to you.',
    '"Bring the battery to combat readiness."\nIt is time to fire back.'
  ];
  const charDelay = char => char === '\n' ? 220 : '.!?'.includes(char) ? 190 : ',;:'.includes(char) ? 110 : char === ' ' ? 26 : 38;
  const hold = index => index === 0 ? 1800 : index === scenes.length - 1 ? 2800 : 2100;
  const duration = scenes.reduce((sum,text,index) => sum + 300 + Array.from(text).reduce((n,char)=>n+charDelay(char),0) + hold(index),0);
  find('runtime').textContent = Math.round(duration / 1000) + ' SEC';
  scenes.forEach(text => { const p = document.createElement('p');p.textContent = text;story.appendChild(p); });
  let timer = null, nextAction = null, remaining = 0, deadline = 0;
  let playing = false, paused = false, suspended = false;
  let sceneIndex = 0, charIndex = 0, characters = [], glyphs = [];
  function queue(action, ms) {
    clearTimeout(timer);
    timer = null;
    nextAction = action;
    remaining = ms;
    if (!playing || paused || suspended) return;
    deadline = performance.now() + ms;
    timer = setTimeout(() => { timer = null;const actionToRun = nextAction;nextAction = null;if (playing && !paused && !suspended && actionToRun) actionToRun(); }, ms);
  }
  function freeze() {
    music.pause();
    if (timer !== null) { remaining = Math.max(0,deadline - performance.now());clearTimeout(timer);timer = null; }
  }
  function resume() { if (playing && !paused && !suspended && nextAction) { queue(nextAction,remaining);playMusic(); } }
  // Both normal completion and Skip Intro use this single exit path.
  function finish(skipped = false) {
    if (!playing) return;
    music.pause();music.currentTime = 0;
    clearTimeout(timer);timer = null;nextAction = null;playing = false;
    stage.hidden = true;landing.hidden = true;transcript.hidden = true;ending.hidden = false;
    replay.focus({preventScroll:true});
    root.dispatchEvent(new CustomEvent('introcomplete', {
      bubbles: true,
      detail: { mission: 1, skipped }
    }));
  }
  function nextScene() { sceneIndex += 1;if (sceneIndex >= scenes.length) finish();else showScene(); }
  function typeNext() {
    if (charIndex >= glyphs.length) { queue(nextScene,hold(sceneIndex));return; }
    if (charIndex > 0) glyphs[charIndex - 1].classList.remove('dw-tip');
    glyphs[charIndex].classList.add('dw-shown');
    glyphs[charIndex].classList.add('dw-tip');
    const delay = charDelay(characters[charIndex]);
    charIndex += 1;
    queue(typeNext,delay);
  }
  function showScene() {
    typed.replaceChildren();
    characters = Array.from(scenes[sceneIndex]);charIndex = 0;
    accessible.textContent = scenes[sceneIndex];
    glyphs = characters.map(char => { const node = document.createElement('span');node.className = 'dw-char';node.textContent = char;typed.appendChild(node);return node; });
    queue(typeNext,300);
  }
  function start() {
    clearTimeout(timer);timer = null;
    playing = true;paused = false;suspended = document.hidden;sceneIndex = 0;
    music.currentTime = 0;audioBlocked = false;updateSound();playMusic();
    pause.textContent = 'PAUSE';pause.setAttribute('aria-pressed','false');
    landing.hidden = true;ending.hidden = true;transcript.hidden = true;stage.hidden = false;
    showScene();skip.focus({preventScroll:true});
  }
  sound.addEventListener('click',() => {
    if (audioBlocked) {audioBlocked = false;music.muted = false;playMusic();}
    else {music.muted = !music.muted;if (!music.muted) playMusic();}
    updateSound();
  });
  play.addEventListener('click',start);
  replay.addEventListener('click',start);
  skip.addEventListener('click',() => finish(true));
  pause.addEventListener('click',() => {
    if (!playing) return;
    if (paused) {paused = false;resume();} else {freeze();paused = true;}
    pause.textContent = paused ? 'RESUME' : 'PAUSE';pause.setAttribute('aria-pressed',String(paused));
  });
  read.addEventListener('click',() => {landing.hidden = true;transcript.hidden = false;close.focus({preventScroll:true});});
  close.addEventListener('click',() => {transcript.hidden = true;landing.hidden = false;play.focus({preventScroll:true});});
  document.addEventListener('visibilitychange',() => {
    if (!playing) return;
    if (document.hidden) {freeze();suspended = true;} else {suspended = false;resume();}
  });
  // Call start() from your existing Play button if you embed this intro.
  window.airDefenseIntro = Object.freeze({
    start,
    skip: () => finish(true)
  });
})();
